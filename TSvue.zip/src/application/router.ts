import { type RouteRecordRaw, createRouter, createWebHistory } from 'vue-router'
import Site from '@/presentation/screens/Site.vue'
import Simple from '@/presentation/screens/Sipmle.vue'


const routes: RouteRecordRaw[] = [
  {
    path: '/',
    component: Simple,
  },
  {
    path: '/site/:id',
    component: Site,
    props: route => ({
      id: parseInt(route.params.id as string, 10),
    }),
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router