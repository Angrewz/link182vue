<template>
  <div>
    <p v-if="!editing">{{ linkContent }}</p>
    <input v-else v-model="editedLinkContent">
    <button @click="toggleEditing">{{ editing ? 'Сохранить' : 'Редактировать' }}</button>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";

const linkContent = ref("Ваша ссылка здесь");
const editedLinkContent = ref("");
const editing = ref(false);

const toggleEditing = () => {
  if (editing.value) {
    linkContent.value = editedLinkContent.value;
  }
  editedLinkContent.value = linkContent.value;
  editing.value = !editing.value;
};
</script>
