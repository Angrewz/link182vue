<script setup lang="ts">
import { List, ListItem, Sections, Section, Placeholder, Avatar, Text, Lottie } from '@/presentation/components'
import { useSite } from '@/domain/services/useSite'
import { type ComputedRef, computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useTelegram, useThumbnail, useLottie } from '@/application/services'
import { useRouter } from 'vue-router'

const props = defineProps({
  id: Number,
}) as {
  id: number | undefined;
}

const id = computed(() => {
  return props.id
})

/**
 * Site got by router param
 */
const { site } = id.value !== undefined ? useSite(id as ComputedRef<number>) : { site: undefined }

/**
 * Methods for Showing/hiding Back button
 */
const { showBackButton, hideBackButton } = useTelegram()

/**
 * Router instance
 */
const router = useRouter()

/**
 * Thumbnail url and loading state
 */
const { pictureUrl, isPictureLoaded } = site?.value?.pictureThumb !== undefined
  ? useThumbnail(site.value.picture, site.value.pictureThumb)
  : { pictureUrl: undefined, isPictureLoaded: false }

</script>
<template>
  <div v-if="site">
    <Sections>
      <Placeholder
        :title="site.title"
        :caption="site.subtitle"
      >
        <template #picture>
          <Avatar
            :src="site.picture"
            :picture-thumb="site.pictureThumb"
            big
          />
        </template>
      </Placeholder>

      <Section
        title="About"
        padded
      >
        <Text>
          {{ site.description }}
        </Text>
      </Section>
      <Section
        title="Links"
        padded
      >
        <List gapped>
          <ListItem
            v-for="link in site.links"
            :id="link.id"
            :key="site.id + '@' + link.id"
            :title="link.title"
            :subtitle="link.subtitle"
            :to="`http://ya.ru`"
            big-avatar
            standalone
          >
            <template #picture>
              <Avatar
                :src="link.picture"
                :picture-thumb="link.pictureThumb"
                big
              />
            </template>
            <template #right>
              <div class="link-cell-right">
                <div class="go">
                  >
                </div>
              </div>
            </template>
          </ListItem>
        </List>
      </Section>
      <Section
        title="Ad"
        padded
      >
        <Text>
          {{ site.description }}
        </Text>
      </Section>
    </Sections>
  </div>
  <Placeholder
    v-else
    title="Nothing found"
    caption="Try searching for something else"
    :compact="true"
  >
    <template #picture>
      👀
    </template>
  </Placeholder>
</template>

<style scoped>
@import '@/presentation/styles/theme/typescale.css';

.cover {
  position: relative;
  height: 200px;
  background-color: var(--color-bg);
  background-size: cover;
  background-position: 50% 50%;

  &--loading::after{
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 100%;
    backdrop-filter: blur(20px);
  }
}

.link-cell-right {
    text-align: center;
}
  
.view-enter-from ,
.view-leave-to {
  opacity: 0;
}

.view-enter-active,
.view-leave-active {
  transition: opacity 250ms ease;
}
</style>