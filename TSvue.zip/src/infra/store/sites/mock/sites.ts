import type Site from '@/domain/entities/Site'
import Thumbnails from '@/infra/store/thumbs/thumbs.json'

const sitesMock = [
  {
    id: 1,
    title: 'Just Another Day',
    subtitle: 'Genius, Billionaire, Playboy, Philanthropist',
    description: 'When I was fifteen, sixteen, when I started really to play guitar I definitely wanted to become a musician. It was almost impossible because, it was the dream was so big that I didnt see any chance. Because I was living in a little town, was studying.',
   picture: '/pics/hotel-1.jpg',
    links: [
      {
        id: 1,
        title: 'Design District',
        subtitle: 'My Channel About Design',
        picture: '/pics/room-1-1.jpg',
      },
      {
        id: 2,
        title: 'Remove Background',
        subtitle: 'Really Useful Bot',
        picture: '/pics/room-1-2.jpg',
      },
      {
        id: 3,
        title: 'My Personal Site',
        subtitle: 'godsavethe.web',
        picture: '/pics/room-1-2.jpg',
      },
    ],
  },
]

/**
 * Add picture thumb to an entity based on the picture name
 *
 * @param entity - something with "picture" property
 */
function addThumb<T extends { picture: string }>(entity: T): T & { pictureThumb: string } {
  const pictureName = entity.picture.split('/').pop() as keyof typeof Thumbnails.thumbs

  return {
    ...entity,
    pictureThumb: Thumbnails.thumbs[pictureName],
  }
}

/**
 * Add picture thumbs to sites based on the picture name
 */
function addThumbs(sites: Site[]): Site[] {
  return sites.map((sites) => {
    /**
     * Add picture thumb to links as well
     */
    site.links = site.links.map(addThumb)

    return addThumb(site)
  })
}

export const sites = addThumbs(sitesMock)