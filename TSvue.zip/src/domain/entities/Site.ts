import type { Link } from '.'

export default interface Site {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  address: string;
  price: number;
  picture: string;
  pictureThumb?: string;
  ratingsCount: number;
  links: Link[];
}