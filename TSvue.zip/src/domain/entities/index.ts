import type Site from './Site'
import type Link from './Link'

export type {
  Site,
  Link,
}