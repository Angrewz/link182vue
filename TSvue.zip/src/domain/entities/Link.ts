export default interface Link {
  id: number;
  title: string;
  subtitle: string;
  price: number;
  picture: string;
  pictureThumb?: string;
}