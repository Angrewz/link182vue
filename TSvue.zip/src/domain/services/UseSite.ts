import { sites } from '@/infra/store/hotels/mock/sites'
import { type ComputedRef, computed, type MaybeRefOrGetter, unref } from 'vue'
import type Site from '../entities/Site'

interface useSiteComposableState {
  site: ComputedRef<Site | undefined>;
}

export function useSite(id: MaybeRefOrGetter<number | undefined>): useSiteComposableState {
  const siteId = unref(id)

  if (siteId === undefined) {
    throw new Error('Site ID is not defined')
  }

  const site = computed(() => {
    return sites.find((site) => site.id === siteId)
  })

  return {
    site,
  }
}